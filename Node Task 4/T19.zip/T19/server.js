const express = require('express');
const app = express();
const PORT = 3000;

const adminRoutes = require('./routes/admin');

app.use('/admin', adminRoutes);

app.get('/', (req, res) => {
  res.json({ message: "Public route working" });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});