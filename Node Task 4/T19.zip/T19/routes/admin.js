const express = require('express');
const router = express.Router();

function authMiddleware(req, res, next) {
  console.log("Auth check");

  const token = req.headers.token;

  if (!token || token !== "12345") {
    console.log("Unauthorized access");

    return res.status(401).json({
      error: "Unauthorized access"
    });
  }

  next();
}

router.use(authMiddleware);

router.get('/dashboard', (req, res) => {
  console.log("Admin dashboard accessed");

  res.status(200).json({
    message: "Access granted to admin dashboard"
  });
});

module.exports = router;