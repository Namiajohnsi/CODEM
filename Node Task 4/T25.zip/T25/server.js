const express = require('express');
const app = express();
const PORT = 3000;

const logger = require('./middleware/logger');
const userRoutes = require('./routes/users');
const productRoutes = require('./routes/products');

app.use(express.json());
app.use(logger);

app.use('/api/users', userRoutes);
app.use('/api/products', productRoutes);

app.get('/', (req, res) => {
  res.json({
    success: true,
    message: "API running successfully"
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
