function auth(req, res, next) {
  const token = req.headers.token;

  if (!token || token !== "12345") {
    return res.status(401).json({
      error: "Unauthorized access"
    });
  }

  next();
}

module.exports = auth;
