let products = [];

function getProducts(req, res) {
  res.status(200).json(products);
}

function createProduct(req, res) {
  const { name, price } = req.body;

  if (!name || typeof price !== 'number') {
    return res.status(400).json({
      error: "Invalid product data"
    });
  }

  const product = {
    id: products.length + 1,
    name,
    price
  };

  products.push(product);

  res.status(201).json(product);
}

module.exports = { getProducts, createProduct };
