let users = [];

function getUsers(req, res) {
  res.status(200).json(users);
}

function createUser(req, res) {
  const { name, email } = req.body;

  if (!name || !email) {
    return res.status(400).json({
      error: "Name and email required"
    });
  }

  const user = {
    id: users.length + 1,
    name,
    email
  };

  users.push(user);

  res.status(201).json(user);
}

module.exports = { getUsers, createUser };
