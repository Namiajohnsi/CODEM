const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.json());

const orderRoutes = require('./routes/orders');

app.use('/api/orders', orderRoutes);

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});