const express = require('express');
const router = express.Router();

let orders = [];

function isValidOrder(order) {
  return order.product && typeof order.quantity === 'number';
}

router.get('/', (req, res) => {
  console.log("GET /orders");

  res.status(200).json({
    message: "All orders",
    totalOrders: orders.length,
    data: orders
  });
});

router.post('/', (req, res) => {
  console.log("POST /orders");

  const newOrder = req.body;

  if (!isValidOrder(newOrder)) {
    return res.status(400).json({
      error: "Product and numeric quantity required"
    });
  }

  const order = {
    orderId: orders.length + 5001,
    product: newOrder.product,
    quantity: newOrder.quantity
  };

  orders.push(order);

  res.status(201).json(order);
});

module.exports = router;