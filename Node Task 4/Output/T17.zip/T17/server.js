const express = require('express');
const app = express();
const PORT = 3000;

const userRoutes = require('./routes/users');

app.use('/api/users', userRoutes);

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});