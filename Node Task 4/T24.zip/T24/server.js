const express = require('express');
const app = express();
const PORT = 3000;

const logger = require('./middleware/logger');
const userRoutes = require('./routes/users');

app.use(express.json());
app.use(logger);

app.use('/api/users', userRoutes);

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
