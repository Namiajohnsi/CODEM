function getUsers(req, res) {
  console.log("Controller executed");

  res.status(200).json({
    message: "Application running successfully"
  });
}

module.exports = { getUsers };
