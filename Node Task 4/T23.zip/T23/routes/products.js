const express = require('express');
const router = express.Router();

router.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

router.get('/', (req, res) => {
  res.status(200).json({
    message: "Products API working"
  });
});

router.get('/details', (req, res) => {
  res.status(200).json({
    message: "Product details route"
  });
});

module.exports = router;