const express = require('express');
const app = express();
const PORT = 3000;

const productRoutes = require('./routes/products');

app.use('/products', productRoutes);

app.get('/', (req, res) => {
  res.json({ message: "Home route" });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});