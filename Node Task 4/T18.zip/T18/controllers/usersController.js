function getUsers(req, res) {
  console.log("Controller executed");

  res.status(200).json({
    message: "Controller executed successfully"
  });
}

module.exports = { getUsers };