const express = require('express');
const router = express.Router();

function authMiddleware(req, res, next) {
  console.log("Checking admin access");

  const token = req.headers.token;

  if (!token || token !== "admin123") {
    console.log("Unauthorized admin access");

    return res.status(401).json({
      error: "Unauthorized access"
    });
  }

  next();
}

router.use(authMiddleware);

router.get('/', (req, res) => {
  console.log("Admin route accessed");

  res.status(200).json({
    message: "Welcome Admin"
  });
});

module.exports = router;