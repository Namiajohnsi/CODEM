const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.json());

const adminRoutes = require('./routes/admin');

app.get('/', (req, res) => {
  res.json({ message: "Public route working" });
});

app.use('/admin', adminRoutes);

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});