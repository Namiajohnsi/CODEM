const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  console.log("Products route accessed");

  res.status(200).json({
    message: "Products API working"
  });
});

module.exports = router;