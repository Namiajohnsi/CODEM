const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  console.log("Orders route accessed");

  res.status(200).json({
    message: "Orders API working"
  });
});

module.exports = router;