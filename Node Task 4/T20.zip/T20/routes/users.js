const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  console.log("Users route accessed");

  res.status(200).json({
    message: "Users API working"
  });
});

module.exports = router;